# Vueform Default Icons

These are the default icon SVGs of Vueform's built-in themes, extracted from the `data:image/svg+xml` URLs the theme tokens ship with. Use them when your Content Security Policy forbids `img-src data:` — host them as same-origin assets and point the tokens at them, and your forms keep the default looks without the `data:` directive.

Copy the files into your app's public assets (for example `public/icons/`), then override the tokens:

```js
createVueform({
  tokens: {
    choiceIconChecked: 'url("/icons/choice-icon-checked.svg")',
    choiceIconSelected: 'url("/icons/choice-icon-selected.svg")',
    iconAdd: 'url("/icons/icon-add.svg")',
    iconLoading: 'url("/icons/icon-loading.svg")',
    iconRemove: 'url("/icons/icon-remove.svg")',
    iconSort: 'url("/icons/icon-sort.svg")',
    selectIconCaret: 'url("/icons/select-icon-caret.svg")',
    stepsIconCompleted: 'url("/icons/steps-icon-completed.svg")',
    stepsIconDanger: 'url("/icons/steps-icon-danger.svg")',
    stepsIconSelected: 'url("/icons/steps-icon-selected.svg")',
  },
})
```

A `dark.`-prefixed token below is the dark token set's default — override it inside your dark tokens the same way.

| Token | File |
| --- | --- |
| `choiceIconChecked` | choice-icon-checked.svg |
| `choiceIconSelected` | choice-icon-selected.svg |
| `iconAdd` | icon-add.svg |
| `iconLoading` | icon-loading.svg |
| `iconRemove` | icon-remove.svg |
| `iconSort` | icon-sort.svg |
| `dark.selectIconCaret` | select-icon-caret-dark.svg |
| `selectIconCaret` | select-icon-caret.svg |
| `stepsIconCompleted` | steps-icon-completed.svg |
| `stepsIconDanger` | steps-icon-danger.svg |
| `stepsIconSelected` | steps-icon-selected.svg |

Icons drawn in `currentColor` take their color from your theme; a file with a fixed color is safe to edit to match yours.

The Content Security Policy details live in the security guide: https://vueform.com/guide/security#content-security-policy
