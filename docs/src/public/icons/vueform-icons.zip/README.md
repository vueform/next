# Vueform Default Icons

These are Vueform's stock icon SVGs, extracted from the `data:image/svg+xml` URLs the default theme tokens ship with. Use them when your Content Security Policy forbids `img-src data:` — host them as same-origin assets and point the icon tokens at them, and your forms keep the default looks without the `data:` directive.

Copy the files into your app's public assets (for example `public/icons/`), then override the tokens:

```js
createVueform({
  tokens: {
    iconAdd: 'url("/icons/add.svg")',
    iconRemove: 'url("/icons/remove.svg")',
    iconSort: 'url("/icons/sort.svg")',
    iconLoading: 'url("/icons/loading.svg")',
    selectIconCaret: 'url("/icons/select-caret.svg")',
    choiceIconChecked: 'url("/icons/choice-checked.svg")',
    choiceIconSelected: 'url("/icons/choice-selected.svg")',
    stepsIconSelected: 'url("/icons/steps-selected.svg")',
    stepsIconCompleted: 'url("/icons/steps-completed.svg")',
    stepsIconDanger: 'url("/icons/steps-danger.svg")',
  },
})
```

| Token | File |
| --- | --- |
| `iconAdd` | add.svg |
| `iconRemove` | remove.svg |
| `iconSort` | sort.svg |
| `iconLoading` | loading.svg |
| `selectIconCaret` | select-caret.svg (select-caret-dark.svg is the `dark` token set's default) |
| `choiceIconChecked` | choice-checked.svg |
| `choiceIconSelected` | choice-selected.svg |
| `stepsIconSelected` | steps-selected.svg |
| `stepsIconCompleted` | steps-completed.svg |
| `stepsIconDanger` | steps-danger.svg |

Most icons draw in `currentColor` (they are applied as CSS masks, so the color comes from your theme either way). The select carets carry a fixed stroke color and the steps icons a fixed `white` fill — edit those freely to match your theme.

The Content Security Policy details live in the security guide: https://vueform.com/guide/security#content-security-policy
